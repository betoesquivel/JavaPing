JavaPing
Autores/Authors: 
José Alberto Esquivel Patiño A01139626
Edgar Ovidio Villarreal Treviño A01139665
========
Proyecto final para mi clase de redes...
Final project for my networking class...

Instrucciones: 
1)Descomprima los archivos.
2)Navegue en la línea de comandos hasta donde descomprimió los archivos.
3)Compile los archivos ejecutando el siguiente comando.
    javac *.java
4)Corra el servidor con el siguiente comando: 
    java Servidor
5)Deje esa ventana con el servidor corriendo. Y en otra ventana de 
linea de comandos, navegue hasta donde se encuentran los archivos y 
ejecute el cliente con el siguiente comando: 
    java Ping localhost

Notas: Opcionalmente, al correr el Servidor puede agregar un número
entero de entre 0 y 20 inclusive para ordenar al Servidor simular 
la pérdida de paquetes entre (0% - 20%)

Instructions: 
1)Unzip the files anywhere.
2)Navigate from command line to files location.
3)Compile the files with the following command: 
    javac *.java
4)Run the Servidor.class file with the following command:
    java Servidor
5)Leave that command line window open and running. And 
on another command line window navigate to files location and run
the ping program with
    java Ping localhost

Notes: Optionally when running the server you can add a number
from 0-20 that orders it to simulate packet loss (0%-20%)


